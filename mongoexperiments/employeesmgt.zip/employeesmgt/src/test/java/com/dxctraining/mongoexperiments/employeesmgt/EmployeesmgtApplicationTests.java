package com.dxctraining.mongoexperiments.employeesmgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesmgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
