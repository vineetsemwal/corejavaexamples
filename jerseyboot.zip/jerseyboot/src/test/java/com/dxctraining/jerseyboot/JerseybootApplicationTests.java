package com.dxctraining.jerseyboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JerseybootApplicationTests {

	@Test
	void contextLoads() {
	}

}
