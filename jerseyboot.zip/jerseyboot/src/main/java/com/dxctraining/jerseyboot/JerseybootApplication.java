package com.dxctraining.jerseyboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JerseybootApplication {

	public static void main(String[] args) {
		SpringApplication.run(JerseybootApplication.class, args);
	}

}
